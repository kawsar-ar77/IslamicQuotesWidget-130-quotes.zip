# Islamic Quotes — Android 16 Widget

A polished Android home-screen widget inspired by the supplied UI reference.

## Included

- 4×1-style live widget preview
- 134 built-in quotes (66 Islamic + 68 motivational)
- Islamic + motivation categories
- 3-hour default rotation
- WorkManager scheduling
- Onyx Dark / Default / Clean Light / Midnight / Emerald backgrounds
- Decorative quotation-mark toggle
- Scripture/source reference toggle
- Previous / Next preview controls
- "Save Widget" pin-widget flow on supported launchers
- Offline operation — no network permission
- Android 16 target (SDK 36)
- GitHub Codespaces configuration

## Android Studio

Open the project folder and let Gradle sync.

Then:

1. Run the app.
2. Configure the widget.
3. Tap **Save Widget**.
4. Confirm the launcher widget pin prompt if shown.

## GitHub Codespaces

Open this folder as a repository in Codespaces. The included `.devcontainer/devcontainer.json` provides an Android/Java development environment.

If Gradle wrapper files are not present, Android Studio can generate them, or use the Gradle installation available in the Codespaces image.

## Important timing note

The default rotation is **3 hours** using WorkManager. Android may delay background work because of Doze, battery optimization, or launcher/device policies. The app therefore aims for a 3-hour interval rather than promising millisecond-exact changes.

## Changing quote content

Edit:

`app/src/main/java/com/kawsar/islamicquotes/QuoteRepository.kt`

The first 65 entries are Islamic reflections and the remaining 65 are motivational reminders.

For published builds, verify every religious quotation and citation against your preferred authoritative Qur'an/Hadith source before distribution.
