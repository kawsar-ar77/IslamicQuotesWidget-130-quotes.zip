package com.kawsar.islamicquotes

data class Quote(
    val text: String,
    val category: String,
    val source: String
)
