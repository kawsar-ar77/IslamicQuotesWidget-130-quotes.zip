package com.kawsar.islamicquotes

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class QuoteRotationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        QuoteStore.next(applicationContext)
        QuoteWidgetProvider.refreshAll(applicationContext)
        return Result.success()
    }
}

object QuoteScheduler {
    private const val WORK_NAME = "quote_rotation"

    fun schedule(context: Context) {
        val hours = QuoteStore.intervalHours(context).coerceAtLeast(1)
        val request = PeriodicWorkRequestBuilder<QuoteRotationWorker>(
            hours.toLong(), TimeUnit.HOURS
        ).build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            androidx.work.ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
