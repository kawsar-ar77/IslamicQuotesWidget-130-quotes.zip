package com.kawsar.islamicquotes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
        QuoteScheduler.schedule(context)
    }

    override fun onEnabled(context: Context) {
        QuoteScheduler.schedule(context)
    }

    override fun onDisabled(context: Context) {
        androidx.work.WorkManager.getInstance(context)
            .cancelUniqueWork("quote_rotation")
    }

    companion object {
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, QuoteWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach {
                updateWidget(context, manager, it)
            }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val q = QuoteStore.current(context)
            val views = RemoteViews(context.packageName, R.layout.widget_quote)

            views.setTextViewText(R.id.widget_quote, "“${q.text}”")
            views.setTextViewText(R.id.widget_source, if (QuoteStore.source(context)) "— ${q.source}" else "")
            views.setViewVisibility(
                R.id.widget_quote_mark_top,
                if (QuoteStore.marks(context)) android.view.View.VISIBLE else android.view.View.GONE
            )
            views.setViewVisibility(
                R.id.widget_quote_mark_bottom,
                if (QuoteStore.marks(context)) android.view.View.VISIBLE else android.view.View.GONE
            )

            val bg = when (QuoteStore.background(context)) {
                "Onyx Dark" -> R.color.bg
                "Clean Light" -> android.R.color.white
                "Midnight" -> R.color.blue_dark
                "Emerald" -> R.color.green
                else -> R.color.surface2
            }
            views.setInt(R.id.widget_root, "setBackgroundColor", context.getColor(bg))

            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)

            manager.updateAppWidget(id, views)
        }
    }
}
