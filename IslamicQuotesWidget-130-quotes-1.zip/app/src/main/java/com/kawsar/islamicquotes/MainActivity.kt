package com.kawsar.islamicquotes

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var previewIndex = 0

    private lateinit var counter: TextView
    private lateinit var previewQuote: TextView
    private lateinit var previewSource: TextView
    private lateinit var topMark: TextView
    private lateinit var bottomMark: TextView
    private lateinit var selectedBackground: TextView

    private val backgrounds = listOf(
        "Default" to "#191A1F",
        "Onyx Dark" to "#0E0E12",
        "Clean Light" to "#FFFFFF",
        "Midnight" to "#172B4D",
        "Emerald" to "#20A878"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        counter = findViewById(R.id.page_counter)
        previewQuote = findViewById(R.id.preview_quote)
        previewSource = findViewById(R.id.preview_source)
        topMark = findViewById(R.id.preview_mark_top)
        bottomMark = findViewById(R.id.preview_mark_bottom)
        selectedBackground = findViewById(R.id.background_selected)

        previewIndex = QuoteRepository.quotes.indexOf(QuoteStore.current(this)).coerceAtLeast(0)

        setupBackgrounds()

        findViewById<Button>(R.id.previous).setOnClickListener {
            previewIndex = (previewIndex - 1 + QuoteRepository.quotes.size) % QuoteRepository.quotes.size
            renderPreview()
        }

        findViewById<Button>(R.id.next).setOnClickListener {
            previewIndex = (previewIndex + 1) % QuoteRepository.quotes.size
            renderPreview()
        }

        val marks = findViewById<Switch>(R.id.quotation_switch)
        val source = findViewById<Switch>(R.id.source_switch)
        marks.isChecked = QuoteStore.marks(this)
        source.isChecked = QuoteStore.source(this)

        marks.setOnCheckedChangeListener { _, checked ->
            QuoteStore.setMarks(this, checked)
            renderPreview()
        }

        source.setOnCheckedChangeListener { _, checked ->
            QuoteStore.setSource(this, checked)
            renderPreview()
        }

        findViewById<Button>(R.id.save_widget).setOnClickListener {
            QuoteStore.setPreviewIndex(this, previewIndex)
            QuoteScheduler.schedule(this)
            refreshWidgets()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = AppWidgetManager.getInstance(this)
                val provider = ComponentName(this, QuoteWidgetProvider::class.java)
                if (manager.isRequestPinAppWidgetSupported) {
                    manager.requestPinAppWidget(provider, null, null)
                } else {
                    Toast.makeText(this, "Add the widget from your home-screen widget list.", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Add the widget from your home-screen widget list.", Toast.LENGTH_LONG).show()
            }
        }

        renderPreview()
    }

    private fun setupBackgrounds() {
        val container = findViewById<LinearLayout>(R.id.background_options)

        backgrounds.forEach { (name, hex) ->
            val wrapper = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(125, 110).apply {
                    marginEnd = 12
                }
                setOnClickListener {
                    QuoteStore.setBackground(this@MainActivity, name)
                    selectedBackground.text = name
                    renderPreview()
                    refreshWidgets()
                    setupBackgrounds()
                }
            }

            val swatch = TextView(this).apply {
                text = if (QuoteStore.background(this@MainActivity) == name) "✓" else ""
                gravity = android.view.Gravity.CENTER
                textSize = 22f
                setTextColor(if (name == "Clean Light") android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 20f
                    setColor(android.graphics.Color.parseColor(hex))
                    if (QuoteStore.background(this@MainActivity) == name) {
                        setStroke(5, android.graphics.Color.parseColor("#1287FF"))
                    } else {
                        setStroke(1, android.graphics.Color.parseColor("#555761"))
                    }
                }
                layoutParams = LinearLayout.LayoutParams(112, 72)
            }

            val label = TextView(this).apply {
                text = name
                gravity = android.view.Gravity.CENTER
                setTextColor(if (QuoteStore.background(this@MainActivity) == name)
                    android.graphics.Color.parseColor("#1287FF")
                else android.graphics.Color.parseColor("#B9B7C0"))
                textSize = 12f
                setPadding(0, 7, 0, 0)
            }

            wrapper.addView(swatch)
            wrapper.addView(label)
            container.addView(wrapper)
        }
        selectedBackground.text = QuoteStore.background(this)
    }

    private fun renderPreview() {
        val q = QuoteRepository.quotes[previewIndex]
        counter.text = "${previewIndex + 1} of ${QuoteRepository.quotes.size}"
        previewQuote.text = q.text
        previewSource.text = if (QuoteStore.source(this)) "— ${q.source}" else ""
        topMark.visibility = if (QuoteStore.marks(this)) android.view.View.VISIBLE else android.view.View.GONE
        bottomMark.visibility = if (QuoteStore.marks(this)) android.view.View.VISIBLE else android.view.View.GONE

        val color = when (QuoteStore.background(this)) {
            "Onyx Dark" -> "#0E0E12"
            "Clean Light" -> "#FFFFFF"
            "Midnight" -> "#172B4D"
            "Emerald" -> "#20A878"
            else -> "#191A1F"
        }
        findViewById<LinearLayout>(R.id.preview_card).setBackgroundColor(android.graphics.Color.parseColor(color))
        previewQuote.setTextColor(
            if (QuoteStore.background(this) == "Clean Light") android.graphics.Color.BLACK
            else android.graphics.Color.WHITE
        )
    }

    private fun refreshWidgets() {
        QuoteWidgetProvider.refreshAll(this)
    }
}
