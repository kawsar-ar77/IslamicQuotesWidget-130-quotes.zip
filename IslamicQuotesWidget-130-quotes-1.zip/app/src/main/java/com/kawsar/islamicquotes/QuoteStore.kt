package com.kawsar.islamicquotes

import android.content.Context

object QuoteStore {
    private const val PREFS = "quote_widget_preferences"
    private const val INDEX = "index"
    private const val MODE = "mode"
    private const val BG = "background"
    private const val MARKS = "quotation_marks"
    private const val SOURCE = "source"
    private const val INTERVAL = "interval_hours"

    fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun mode(context: Context) = prefs(context).getString(MODE, "BOTH") ?: "BOTH"
    fun setMode(context: Context, value: String) = prefs(context).edit().putString(MODE, value).apply()

    fun background(context: Context) = prefs(context).getString(BG, "Default") ?: "Default"
    fun setBackground(context: Context, value: String) = prefs(context).edit().putString(BG, value).apply()

    fun marks(context: Context) = prefs(context).getBoolean(MARKS, true)
    fun setMarks(context: Context, value: Boolean) = prefs(context).edit().putBoolean(MARKS, value).apply()

    fun source(context: Context) = prefs(context).getBoolean(SOURCE, false)
    fun setSource(context: Context, value: Boolean) = prefs(context).edit().putBoolean(SOURCE, value).apply()

    fun intervalHours(context: Context) = prefs(context).getInt(INTERVAL, 3)
    fun setIntervalHours(context: Context, value: Int) = prefs(context).edit().putInt(INTERVAL, value).apply()

    fun candidates(context: Context): List<Quote> = when (mode(context)) {
        "ISLAMIC" -> QuoteRepository.quotes.filter { it.category == "ISLAMIC" }
        "MOTIVATION" -> QuoteRepository.quotes.filter { it.category == "MOTIVATION" }
        else -> QuoteRepository.quotes
    }

    fun current(context: Context): Quote {
        val list = candidates(context)
        val index = prefs(context).getInt(INDEX, 0).coerceIn(0, list.lastIndex)
        return list[index]
    }

    fun setPreviewIndex(context: Context, index: Int) {
        val list = candidates(context)
        prefs(context).edit().putInt(INDEX, index.coerceIn(0, list.lastIndex)).apply()
    }

    fun next(context: Context): Quote {
        val list = candidates(context)
        val next = (prefs(context).getInt(INDEX, 0) + 1) % list.size
        prefs(context).edit().putInt(INDEX, next).apply()
        return list[next]
    }
}
